package com.example.dice;

public class GameModel{
    public String name, p1, p2;
    public int SC1, SC2;


    //default cons
    public GameModel() {
    }

    //parameterised cons


    public GameModel(String name, String p1, int sc1, String p2, int sc2) {
        this.name=name;
        this.p1=p1;
        this.p2=p2;
        this.SC1=sc1;
        this.SC2=sc2;
    }

    @Override
    public String toString() {
        String s = "NameId= " + name + " PLAYER1= " + p1 + " Score= " + SC1 + " PLAYER2= " + p2 + " Score= " + SC2;
        return s;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getP1() {
        return p1;
    }

    public void setP1(String p1) {
        this.p1 = p1;
    }

    public int getSC1() {
        return SC1;
    }

    public void setSC1(int SC1) {
        this.SC1 = SC1;
    }

    public int getSC2() {
        return SC2;
    }

    public void setSC2(int SC2) {
        this.SC2 = SC2;
    }

    public String getP2() {
        return p2;
    }

    public void setP2(String p2) {
        this.p2 = p2;
    }
}




