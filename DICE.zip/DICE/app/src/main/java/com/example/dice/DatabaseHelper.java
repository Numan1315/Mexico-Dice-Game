package com.example.dice;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;


public class DatabaseHelper extends SQLiteOpenHelper {

    public DatabaseHelper(Context context) {
        super(context, "GameModel", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String create = "CREATE TABLE scoreboard(nameID VARCHAR PRIMARY KEY,p1 VARCHAR,sc1 INTEGER,p2 VARCHAR,sc2 INTEGER)";
        db.execSQL(create);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS scoreboard");
        onCreate(db);
    }

    public boolean addrecord(GameModel gameModel) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM scoreboard";
        Cursor c = db.rawQuery(query, null);
        if (c.moveToFirst()) {
            do {
                String nameID = c.getString(0);
                if (nameID.compareTo(gameModel.getName()) == 0) {
                    c.close();
                    db.close();
                    return true;
                }

            } while (c.moveToNext());
        }
        //contentvalues
        ContentValues cv = new ContentValues();
        cv.put("nameID", gameModel.getName());
        cv.put("p1", gameModel.getP1());
        cv.put("sc1", gameModel.getSC1());
        cv.put("p2", gameModel.getP2());
        cv.put("sc2", gameModel.getSC2());
        long insert = db.insert("scoreboard", null, cv);

        return insert != -1;
    }

    public List<GameModel> getalldata() {
        List<GameModel> display = new ArrayList<>();
        String query = "SELECT * FROM scoreboard";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(query, null);
        if (c.moveToFirst()) {
            do {
                String nameID = c.getString(0);
                String player1 = c.getString(1);
                int sc1 = c.getInt(2);
                String player2 = c.getString(3);
                int sc2 = c.getInt(4);

                GameModel newplayer = new GameModel(nameID, player1, sc1, player2, sc2);
                display.add(newplayer);
            } while (c.moveToNext());
        }

        c.close();
        db.close();

        return display;
    }

    public Integer delete(String id) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.delete("scoreboard", "nameId = ? ", new String[]{id});
    }

    public void update(int winner, String ID) {
        String query = "SELECT * FROM scoreboard";
        SQLiteDatabase db = this.getReadableDatabase();
        ContentValues cv = new ContentValues();
        Cursor c = db.rawQuery(query, null);
        if (c.moveToFirst()) {
            do {
                String nameID = c.getString(0);
                if (nameID.compareTo(ID) == 0) {
                    String player1 = c.getString(1);
                    int sc1 = c.getInt(2);
                    String player2 = c.getString(3);
                    int sc2 = c.getInt(4);
                    if (winner == 0) {
                        sc1 = sc1 + 1;
                        cv.put("SC1", sc1);
                    } else {
                        sc2 = sc2 + 1;
                        cv.put("SC2", sc2);
                    }
                    int n = db.update("scoreboard", cv, "nameID= ?", new String[]{ID});
                    GameModel newplayer = new GameModel(nameID, player1, sc1, player2, sc2);
                    db.close();
                    c.close();
                }


            } while (c.moveToNext());
        }
    }
}

