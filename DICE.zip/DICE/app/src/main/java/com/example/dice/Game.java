package com.example.dice;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class Game extends AppCompatActivity {
    public int winner;
    ImageView iv_dice_p1, iv_dice_p2, iv_lives_p1, iv_lives_p2;
    TextView tv_player1, tv_player2;
    String player1, player2;
    String NAME_ID;
    Random r;

    int livesp1, livesp2;
    int rolledp1, rolledp2;

    Animation animation;


    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        player1 = getIntent().getStringExtra("player1");
        player2 = getIntent().getStringExtra("player2");
        NAME_ID = getIntent().getStringExtra("nameID");
        r = new Random();
        animation = AnimationUtils.loadAnimation(this, R.anim.rotate);

        iv_dice_p1 = findViewById(R.id.iv_dice_p1);
        iv_dice_p2 = findViewById(R.id.iv_dice_p2);

        iv_lives_p1 = findViewById(R.id.iv_lives_p1);
        iv_lives_p2 = findViewById(R.id.iv_lives_p2);

        tv_player1 = findViewById(R.id.tv_player1);
        tv_player2 = findViewById(R.id.tv_player2);

        tv_player1.setText(player1 + " ROLL!");
        tv_player2.setText(player2 + " ROLL!");

        livesp1 = 6;
        livesp2 = 6;
        setDiceImage(livesp1, iv_lives_p1);
        setDiceImage(livesp2, iv_lives_p2);


        iv_dice_p1.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                rolledp1 = r.nextInt(6) + 1;
                setDiceImage(rolledp1, iv_dice_p1);

                if (rolledp2 != 0) {
                    tv_player1.setText(player1 + " ROLL!");
                    tv_player2.setText(player2 + " ROLL!");
                    if (rolledp1 > rolledp2) {
                        livesp2--;
                        setDiceImage(livesp2, iv_lives_p2);
                    }
                    if (rolledp2 > rolledp1) {
                        livesp1--;
                        setDiceImage(livesp1, iv_lives_p1);
                    }

                    checkEndGame();

                    rolledp2 = 0;
                    rolledp1 = 0;

                    iv_dice_p1.setEnabled(true);
                    iv_dice_p2.setEnabled(true);


                } else {
                    tv_player1.setText(player1 + " ROLLED!");
                    iv_dice_p1.setEnabled(false);

                }

            }
        });

        iv_dice_p2.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                rolledp2 = r.nextInt(6) + 1;
                setDiceImage(rolledp2, iv_dice_p2);

                if (rolledp1 != 0) {
                    tv_player1.setText(player1 + " ROLL!");
                    tv_player2.setText(player2 + " ROLL!");
                    if (rolledp1 > rolledp2) {
                        livesp2--;
                        setDiceImage(livesp2, iv_lives_p2);
                    }
                    if (rolledp2 > rolledp1) {
                        livesp1--;
                        setDiceImage(livesp1, iv_lives_p1);
                    }

                    checkEndGame();

                    rolledp2 = 0;
                    rolledp1 = 0;

                    iv_dice_p1.setEnabled(true);
                    iv_dice_p2.setEnabled(true);


                } else {
                    tv_player2.setText(player2 + " ROLLED!");
                    iv_dice_p2.setEnabled(false);

                }

            }
        });

    }

    private void setDiceImage(int dice, ImageView image) {
        switch (dice) {
            case 1:
                image.setImageResource(R.drawable.dice1);
                image.startAnimation(animation);
                break;
            case 2:
                image.setImageResource(R.drawable.dice2);
                image.startAnimation(animation);
                break;
            case 3:
                image.setImageResource(R.drawable.dice3);
                image.startAnimation(animation);
                break;
            case 4:
                image.setImageResource(R.drawable.dice4);
                image.startAnimation(animation);
                break;
            case 5:
                image.setImageResource(R.drawable.dice5);
                image.startAnimation(animation);
                break;
            case 6:
                image.setImageResource(R.drawable.dice6);
                image.startAnimation(animation);
                break;
            default:
                image.setImageResource(R.drawable.dice0);
                image.startAnimation(animation);
        }
    }

    private void checkEndGame() {
        if (livesp1 == 0 || livesp2 == 0) {
            String text = "";
            if (livesp1 != 0) {
                text = "Game Over! Winner " + player1 + " !";
                winner = 0;
            } else {
                text = "Game Over! Winner " + player2 + " !";
                winner = 1;
            }
            DatabaseHelper databaseHelper = new DatabaseHelper(Game.this);
            databaseHelper.update(winner, NAME_ID);
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setCancelable(false);
            alertDialogBuilder.setMessage(text);
            alertDialogBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int i) {
                    finish();
                }
            });
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        }
    }
}
