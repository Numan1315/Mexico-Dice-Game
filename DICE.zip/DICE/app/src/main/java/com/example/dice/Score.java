package com.example.dice;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class Score extends AppCompatActivity {

    Button viewer,delete;
    ListView lv;
    ArrayAdapter adapter;

    EditText text;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);

        viewer=(Button)findViewById(R.id.viewer);
        delete=(Button)findViewById(R.id.delete);
        lv=(ListView)findViewById(R.id.list_view);
        text=(EditText)findViewById(R.id.text);

        viewer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseHelper databaseHelper = new DatabaseHelper(Score.this);
                List<GameModel> all=databaseHelper.getalldata();
                adapter = new ArrayAdapter<GameModel>(Score.this, android.R.layout.simple_list_item_activated_1,all);
                lv.setAdapter(adapter);
                //ArrayAdapter
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseHelper databaseHelper = new DatabaseHelper(Score.this);
                Integer input= databaseHelper.delete(text.getText().toString().toUpperCase());
                if(input > 0)
                    Toast.makeText(Score.this,"deleted successfully",Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(Score.this,"deletion failed",Toast.LENGTH_SHORT).show();
            }
        });
    }
}