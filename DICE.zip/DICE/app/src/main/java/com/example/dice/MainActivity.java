package com.example.dice;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {
    public Button btn, btnscr;
    EditText p1, p2;
    String NAME_ID;
    String pl1, pl2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = findViewById(R.id.btn);
        p1 = findViewById(R.id.p1);
        p2 = findViewById(R.id.p2);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String player1name = p1.getText().toString().toUpperCase();
                String player2Name = p2.getText().toString().toUpperCase();

                if (player1name.isEmpty() && player2Name.isEmpty()) {
                    p1.setError("PLAYER1 NAME IS REQUIRED");
                    p2.setError("PLAYER2 NAME IS REQUIRED");
                } else if (player2Name.isEmpty()) {
                    p2.setError("PLAYER2 NAME IS REQUIRED");
                } else {
                    if (player1name.compareTo(player2Name) > 0) {
                        NAME_ID = player2Name + "VS" + player1name;
                    } else {
                        NAME_ID = player1name + "VS" + player2Name;
                    }
                    if (player1name.compareTo(player2Name) > 0) {
                        pl1 = player2Name;
                        pl2 = player1name;
                    } else {
                        pl1 = player1name;
                        pl2 = player2Name;
                    }

                    try {
                        GameModel gameModel;
                        //create new customer reference object
                        gameModel = new GameModel(NAME_ID, pl1, 0, pl2, 0);
                        DatabaseHelper databaseHelper = new DatabaseHelper(MainActivity.this);

                        boolean b = databaseHelper.addrecord(gameModel);
                        Intent intent = new Intent(MainActivity.this, Game.class);
                        intent.putExtra("player1", pl1);
                        intent.putExtra("player2", pl2);
                        intent.putExtra("nameID", NAME_ID);
                        startActivity(intent);

                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, e.toString(), Toast.LENGTH_SHORT).show();
                    }


                }
            }

        });
        btnscr = findViewById(R.id.btnscr);
        btnscr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Score.class);
                startActivity(intent);
            }


        });


    }
}
